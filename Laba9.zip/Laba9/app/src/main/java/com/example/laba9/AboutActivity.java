package com.example.laba9;

import android.os.Bundle;
import android.view.GestureDetector;
import android.view.MotionEvent;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class AboutActivity extends AppCompatActivity {

    // Объект для распознавания жестов
    private GestureDetector gestureDetector;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_about);

        // Инициализируем детектор жестов
        gestureDetector = new GestureDetector(this, new SwipeListener());
    }

    // Передаем все касания экрана в детектор жестов
    @Override
    public boolean onTouchEvent(MotionEvent event) {
        return gestureDetector.onTouchEvent(event) || super.onTouchEvent(event);
    }

    // Внутренний класс для обработки свайпов
    private class SwipeListener extends GestureDetector.SimpleOnGestureListener {
        private static final int SWIPE_THRESHOLD = 100;
        private static final int SWIPE_VELOCITY_THRESHOLD = 100;

        @Override
        public boolean onFling(MotionEvent e1, MotionEvent e2, float velocityX, float velocityY) {
            float diffX = e2.getX() - e1.getX();
            float diffY = e2.getY() - e1.getY();

            // Проверяем, был ли это горизонтальный свайп
            if (Math.abs(diffX) > Math.abs(diffY)) {
                if (Math.abs(diffX) > SWIPE_THRESHOLD && Math.abs(velocityX) > SWIPE_VELOCITY_THRESHOLD) {
                    if (diffX > 0) {
                        onSwipeRight();
                    } else {
                        onSwipeLeft();
                    }
                    return true;
                }
            }
            return false;
        }
    }

    // Действие при свайпе вправо
    private void onSwipeRight() {
        Toast.makeText(this, "Свайп вправо! Закрываем...", Toast.LENGTH_SHORT).show();
        finish(); // Закрывает это окно и возвращает на главное
    }

    // Действие при свайпе влево
    private void onSwipeLeft() {
        Toast.makeText(this, "Свайп влево! Закрываем...", Toast.LENGTH_SHORT).show();
        finish(); // Тоже закрывает
    }
}
package com.example.laba9; // Твой пакет

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    // 1. Объявляем переменные для всех элементов экрана
    EditText inputAngle;
    RadioButton radioDeg, radioRad;
    Button btnCalc, btnAbout;
    TextView tvResult;
    Spinner spinnerColor;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // 2. Связываем переменные с ID из XML
        inputAngle = findViewById(R.id.inputAngle);
        radioDeg = findViewById(R.id.radioDeg);
        radioRad = findViewById(R.id.radioRad);
        btnCalc = findViewById(R.id.btnCalc);
        tvResult = findViewById(R.id.tvResult);
        btnAbout = findViewById(R.id.btnAbout);
        spinnerColor = findViewById(R.id.spinnerColor);

        // Настройка Списка (Spinner)
        // Создаем массив строк для выбора цвета
        String[] colors = {"Черный", "Синий", "Красный"};
        // Адаптер связывает массив с выпадающим списком
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, colors);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerColor.setAdapter(adapter);

        //Обработка кнопки "Вычислить"
        btnCalc.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Анимация (кнопка чуть уменьшается и возвращается)
                v.animate().scaleX(0.9f).scaleY(0.9f).setDuration(100).withEndAction(new Runnable() {
                    @Override
                    public void run() {
                        v.animate().scaleX(1f).scaleY(1f).setDuration(100);
                    }
                });

                calculateCos(); // Вызов метода расчета
            }
        });

        //Обработка кнопки перехода на вторую активность
        btnAbout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Интерт - намерение открыть новое окно
                Intent intent = new Intent(MainActivity.this, AboutActivity.class);
                startActivity(intent);
            }
        });
    }

    // Метод вычисления
    private void calculateCos() {
        String inputStr = inputAngle.getText().toString();

        // Проверка на пустое поле
        if (inputStr.isEmpty()) {
            tvResult.setText("Ошибка: Введите число!");
            return;
        }

        try {
            double angle = Double.parseDouble(inputStr);
            // Проверка на 0 или отрицательные числа
            // сообщение о недопустимости
            // запрещаем отрицательные углы.
            if (angle < 0) {
                tvResult.setText("Ошибка: Ввод отрицательных чисел запрещен!");
                // Всплывающее сообщение (Toast)
                Toast.makeText(this, "Нельзя вводить минус!", Toast.LENGTH_SHORT).show();
                return;
            }

            // Деление на 0
            // проверка:
            if (angle == 0 && false) {
                tvResult.setText("Ошибка: Деление на 0!");
                return;
            }

            double result = 0;

            // Проверяем, что выбрано: Градусы или Радианы
            if (radioDeg.isChecked()) {
                // Math.cos принимает радианы, поэтому переводим градусы в радианы
                result = Math.cos(Math.toRadians(angle));
            } else {
                result = Math.cos(angle);
            }

            // Форматируем вывод
            tvResult.setText("Cos(" + angle + ") = " + String.format("%.4f", result));

            // Меняем цвет текста через Spinner
            int position = spinnerColor.getSelectedItemPosition();
            if (position == 0) tvResult.setTextColor(Color.BLACK);
            else if (position == 1) tvResult.setTextColor(Color.BLUE);
            else if (position == 2) tvResult.setTextColor(Color.RED);

        } catch (NumberFormatException e) {
            tvResult.setText("Ошибка: Некорректный формат!");
        }
    }
}